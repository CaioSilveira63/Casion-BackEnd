
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'caiosilveira',
  applicationName: 'casion',
  appUid: 'qlzPx0qwtf0yMkKSv5',
  orgUid: '0d00e7bd-0ff0-410d-8d47-c0bd2d4a86f0',
  deploymentUid: '0d4795c8-04bf-43b7-ab5e-8a1285169530',
  serviceName: 'aws-node-mongodb-atlas',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'aws-node-mongodb-atlas-dev-hello', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}